//
//  DrawingApp.swift
//  Drawing
//
//  Created by Student1 on 18/01/2024.
//

import SwiftUI

@main
struct DrawingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
